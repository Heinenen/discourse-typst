# discourse-svgbob

````
```svgbob height=500
*-------------*
| hello world |
*-------------*
```
````

See: https://github.com/ivanceras/svgbob
